
import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { generateMockData } from './services/mockData';
import { processBulkFile, processBusinessReport } from './services/dataProcessor';
import { DashboardData, BusinessReportRow, AppSettings, ProductGoal } from './types';
import { 
  ExecutiveDashboard, 
  PortfolioDashboard, 
  SPDashboard, 
  SBDashboard, 
  SDDashboard, 
  SearchTermDashboard, 
  DiagnosticsDashboard,
  SettingsDashboard,
  AsinAuditDashboard
} from './views/Dashboards';
import { CloudUpload, FileSpreadsheet, Loader2, Shield, CheckCircle } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState('executive');
  const [bulkData, setBulkData] = useState<DashboardData | null>(null);
  const [businessReport, setBusinessReport] = useState<BusinessReportRow[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Default Global Settings
  const [settings, setSettings] = useState<AppSettings>({
    targetAcos: 0.30,      // 30%
    breakEvenAcos: 0.40,   // 40%
    minSpendThreshold: 30, // $30
    minClickThreshold: 15, // 15 clicks
    currencySymbol: '$'
  });

  // Product Level Overrides (ASIN -> Goal)
  const [productGoals, setProductGoals] = useState<Record<string, ProductGoal>>({});

  const handleBulkUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);

    try {
      const processedData = await processBulkFile(file);
      setBulkData(processedData);
    } catch (err) {
      console.error(err);
      setError("Failed to parse the Bulk Operations file. Please ensure it is valid.");
    } finally {
      setLoading(false);
    }
  };

  const handleBusinessReportUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);

    try {
      const report = await processBusinessReport(file);
      setBusinessReport(report);
    } catch (err) {
      console.error(err);
      setError("Failed to parse the Business Report. Ensure it contains Child ASIN data.");
    } finally {
      setLoading(false);
    }
  };

  const loadDemoData = () => {
    setLoading(true);
    setTimeout(() => {
      const mock = generateMockData();
      setBulkData(mock);
      // Create mock business report data
      if (mock.businessReport && mock.businessReport.length > 0) {
        setBusinessReport(mock.businessReport);
      }
      setLoading(false);
    }, 800);
  };

  // Combine data for the dashboard views
  const dashboardData = bulkData ? { ...bulkData, businessReport: businessReport || [] } : null;

  const renderView = () => {
    if (!dashboardData) return null;

    switch (currentView) {
      case 'executive': return <ExecutiveDashboard data={dashboardData} />;
      case 'portfolio': return <PortfolioDashboard data={dashboardData} />;
      case 'asin-audit': return <AsinAuditDashboard data={dashboardData} />;
      case 'sp': return <SPDashboard data={dashboardData} />;
      case 'sb': return <SBDashboard data={dashboardData} />;
      case 'sb-mag': return <SBDashboard data={dashboardData} />; 
      case 'sd': return <SDDashboard data={dashboardData} />;
      case 'search-terms': return <SearchTermDashboard data={dashboardData} targetType="SP" />;
      case 'sb-search-terms': return <SearchTermDashboard data={dashboardData} targetType="SB" />;
      
      // Pass productGoals to Diagnostics for Calculation
      case 'diagnostics': return <DiagnosticsDashboard data={dashboardData} settings={settings} productGoals={productGoals} />;
      
      // Pass productGoals updater to Settings for Management
      case 'settings': return <SettingsDashboard data={dashboardData} settings={settings} onUpdateSettings={setSettings} productGoals={productGoals} onUpdateProductGoals={setProductGoals} />;
      default: return <ExecutiveDashboard data={dashboardData} />;
    }
  };

  // Upload Screen (Landing)
  if (!bulkData) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4 relative overflow-hidden">
        {/* Background decorative blob */}
        <div className="absolute top-0 left-0 w-full h-2 bg-brand-400"></div>
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-brand-100 rounded-full blur-3xl opacity-50"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-slate-100 rounded-full blur-3xl opacity-50"></div>

        <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl p-10 text-center border border-slate-100 relative z-10">
           
           <div className="inline-flex items-center justify-center w-24 h-24 bg-black rounded-2xl shadow-xl shadow-slate-200 mb-8 transform -rotate-3">
              <Shield className="text-brand-400 w-12 h-12 fill-current" strokeWidth={2} />
           </div>
           
           <h1 className="text-5xl font-heading font-black text-slate-900 mb-2 tracking-tighter">
             LYNX<span className="text-brand-500">MEDIA</span>
           </h1>
           <p className="text-slate-400 mb-10 text-lg font-medium tracking-wide">
             EXPERT SOLUTIONS FOR AMAZON STORES
           </p>
           
           {error && (
             <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-700 rounded-xl text-sm font-medium flex items-center justify-center gap-2">
               <Shield className="w-4 h-4" /> {error}
             </div>
           )}

           <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
              {/* Bulk File Upload */}
              <div className="relative group">
                <input 
                  type="file" 
                  accept=".xlsx, .xls"
                  onChange={handleBulkUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  disabled={loading || !!bulkData}
                />
                <div className={`
                  flex flex-col items-center justify-center h-44 px-6 border-2 border-dashed rounded-2xl transition-all duration-300
                  ${bulkData ? 'bg-brand-50 border-brand-400' : 'bg-slate-50 border-slate-200 group-hover:border-brand-500 group-hover:bg-brand-50/30'}
                `}>
                  {bulkData ? (
                     <>
                       <CheckCircle className="w-10 h-10 text-brand-600 mb-3" />
                       <span className="text-sm font-bold text-brand-800">Bulk File Loaded</span>
                     </>
                  ) : (
                     <>
                        <CloudUpload className="w-10 h-10 text-slate-400 group-hover:text-brand-500 transition-colors mb-3" />
                        <span className="text-sm font-bold text-slate-700 group-hover:text-slate-900">Upload Bulk Ops</span>
                        <span className="text-xs text-slate-400 mt-1">.xlsx or .xls</span>
                     </>
                  )}
                </div>
              </div>

              {/* Business Report Upload */}
              <div className="relative group">
                <input 
                  type="file" 
                  accept=".xlsx, .csv"
                  onChange={handleBusinessReportUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  disabled={loading}
                />
                <div className={`
                  flex flex-col items-center justify-center h-44 px-6 border-2 border-dashed rounded-2xl transition-all duration-300
                  ${businessReport ? 'bg-brand-50 border-brand-400' : 'bg-slate-50 border-slate-200 group-hover:border-brand-500 group-hover:bg-brand-50/30'}
                `}>
                   {businessReport ? (
                     <>
                       <CheckCircle className="w-10 h-10 text-brand-600 mb-3" />
                       <span className="text-sm font-bold text-brand-800">Report Loaded</span>
                     </>
                  ) : (
                     <>
                        <FileSpreadsheet className="w-10 h-10 text-slate-400 group-hover:text-brand-500 transition-colors mb-3" />
                        <span className="text-sm font-bold text-slate-700 group-hover:text-slate-900">Business Report</span>
                        <span className="text-xs text-slate-400 mt-1">Child ASIN (Optional)</span>
                     </>
                  )}
                </div>
              </div>
           </div>

           {loading && (
              <div className="flex items-center justify-center text-slate-500 font-bold mb-6 bg-slate-50 py-3 rounded-xl animate-pulse">
                  <Loader2 className="animate-spin mr-3 w-5 h-5 text-brand-500" /> ANALYZING DATA...
              </div>
           )}

           <button 
                onClick={loadDemoData}
                disabled={loading}
                className="w-full py-4 px-6 bg-black text-white font-bold tracking-wide rounded-xl hover:bg-slate-900 hover:shadow-lg hover:shadow-slate-200 transition-all active:scale-[0.98] flex items-center justify-center gap-2 group"
           >
                <Shield className="w-5 h-5 text-brand-400 fill-current group-hover:scale-110 transition-transform" />
                LOAD DEMO DATA
           </button>
        </div>
      </div>
    );
  }

  return (
    <Layout currentView={currentView} setCurrentView={setCurrentView}>
      {renderView()}
    </Layout>
  );
};

export default App;
